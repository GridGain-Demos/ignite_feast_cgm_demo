from feast_gridgain.ignite_online_store import IgniteOnlineStoreConfig, IgniteOnlineStore
from feast_gridgain.gridgain_online_store import GridGainOnlineStoreConfig, GridGainOnlineStore

__version__ = '0.2.0-dev'